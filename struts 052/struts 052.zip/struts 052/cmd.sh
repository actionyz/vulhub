tar -xz -f jdk.tar.gz -C /usr/local/
tar -xz -f apache-tomcat-8.0.46.tar.gz -C /usr/local/
unzip struts.zip -d /usr/local/apache-tomcat-8.0.46/webapps

mv /usr/local/apache-tomcat-8.0.46/webapps/struts-2.5.12/apps/struts2-rest-showcase.war ./../../
# setup jdk
echo '''
JAVA_HOME=/usr/local/jdk1.8.0_144
JAVA_BIN=/usr/local/jdk1.8.0_144/bin
PATH=$PATH:$JAVA_BIN
CLASSPATH=$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export JAVA_HOME JAVA_BIN PATH CLASSPATH
'''>>/etc/profile
source /etc/profile
/usr/local/apache-tomcat-8.0.46/bin/startup.sh

/bin/bash
